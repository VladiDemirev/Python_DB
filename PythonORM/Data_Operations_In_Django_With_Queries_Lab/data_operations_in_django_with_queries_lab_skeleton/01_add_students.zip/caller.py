import os
import django
from datetime import date

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here

from main_app.models import Student


def add_students():
    Student.objects.create(
        student_id="FC5204",
        first_name="John",
        last_name="Doe",
        birth_date="1995-05-15",
        email="john.doe@university.com",
    )

    student = Student()
    student.student_id = "FE0054"
    student.first_name = "Jane"
    student.last_name = "Smith"
    student.email = "jane.smith@university.com"
    student.save()

    student = Student()
    student.student_id = "FH2014"
    student.first_name = "Alice"
    student.last_name = "Johnson"
    student.birth_date = "1998-02-10"
    student.email = "alice.johnson@university.com"
    student.save()

    student = Student(
        student_id="FH2015",
        first_name="Bob",
        last_name="Wilson",
        birth_date="1996-11-25",
        email="bob.wilson@university.com",
    )
    student.save()


# Run and print your queries

# add_students()
# print(Student.objects.all())
